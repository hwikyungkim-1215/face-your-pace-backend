package com.example.faceYourPace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaceYourPaceApplicationTests {

	@Test
	void contextLoads() {
	}

}
