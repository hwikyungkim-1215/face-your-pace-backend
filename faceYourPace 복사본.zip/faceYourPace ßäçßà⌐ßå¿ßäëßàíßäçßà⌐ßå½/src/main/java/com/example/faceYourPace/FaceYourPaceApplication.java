package com.example.faceYourPace;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FaceYourPaceApplication {

	public static void main(String[] args) {

		SpringApplication.run(FaceYourPaceApplication.class, args);
	}

}
