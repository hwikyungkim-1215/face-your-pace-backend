package com.example.faceYourPace.web;

public class SessionConst {
    public static final String LOGIN_MEMBER = "loginMember";
}
