package com.example.faceYourPace.repository;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class PlayListSearch {

    private String userId; // 로그인 ID로 플레이리스트 목록 출력을 위해
}
